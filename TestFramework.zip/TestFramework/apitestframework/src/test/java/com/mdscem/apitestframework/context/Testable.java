package com.mdscem.apitestframework.context;

public interface Testable {

}
