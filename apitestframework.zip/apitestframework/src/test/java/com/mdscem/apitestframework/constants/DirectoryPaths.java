package com.mdscem.apitestframework.constants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

@Configuration
public class DirectoryPaths {

//    @Value("${base.directory.path}")
    private String basePath = "/home/hansakasudusinghe/Documents/Octomber/Update/TestFramework/apitestframework/src/main/resources/";

//    @Value("${report.directory.path}")
    private String reportPath = "/home/hansakasudusinghe/Documents/Octomber/Update/Extent.html";

//    public static String BASE_PATH = System.getProperty("base.directory.path");
        public static String BASE_PATH = "/home/hansakasudusinghe/Documents/Octomber/Update/TestFramework/apitestframework/src/main/resources/";

    public static String TEST_CASES_DIRECTORY = BASE_PATH + "testcases/";
    public static String INCLUDES_DIRECTORY = BASE_PATH + "includes/";
    public static String FLOWS_DIRECTORY = BASE_PATH + "flows/";
    public static String VALIDATION_FILE_PATH = BASE_PATH + "schema.json";
    public static String FLOW_VALIDATION_PATH = BASE_PATH + "flow-validation.json";
    public static String CORE_FRAMEWORK_PATH = BASE_PATH + "framework-config.json";
//    public static String REPORT_PATH = System.getProperty("report.directory.path");
        public static String REPORT_PATH = "/home/hansakasudusinghe/Documents/Octomber/Update/Extent.html";


    @PostConstruct
    public void initPaths() {
        TEST_CASES_DIRECTORY = basePath + "testcases/";
        INCLUDES_DIRECTORY = basePath + "includes/";
        FLOWS_DIRECTORY = basePath + "flows/";
        VALIDATION_FILE_PATH = basePath + "schema.json";
        FLOW_VALIDATION_PATH = basePath + "flow-validation.json";
        CORE_FRAMEWORK_PATH = basePath + "framework-config.json";
        REPORT_PATH = reportPath;
        System.out.println("Initialized REPORT_PATH: " + REPORT_PATH);
    }

    public String getReportPath() {
        return reportPath;
    }
}
