package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = MyTest.class)
class DemoApplicationTests {

	@Autowired
	public MyTest myTest;

	@Test
	void contextLoads() {
		myTest.MyTest();
	}
}
