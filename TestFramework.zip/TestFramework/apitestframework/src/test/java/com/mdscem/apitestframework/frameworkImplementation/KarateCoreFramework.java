package com.mdscem.apitestframework.frameworkImplementation;

import com.mdscem.apitestframework.fileprocessor.filereader.model.TestCase;
import com.mdscem.apitestframework.requestprocessor.CoreFramework;

public class KarateCoreFramework implements CoreFramework {

    @Override
    public String createFrameworkTypeTestFileAndexecute(TestCase testCase) {
        return "";
    }

}